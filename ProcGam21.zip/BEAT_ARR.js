const BEAT_ARR = [
    "1000100010001000",
    "1000000000000000",
    "1000000010000000",
    "1010101010101010",
    "1111111111111111",
].map(n=>n.split("").map(Number));
console.log('BEAT_ARR === ',BEAT_ARR);